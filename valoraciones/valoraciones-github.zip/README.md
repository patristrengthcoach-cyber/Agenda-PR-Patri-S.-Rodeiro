# Valoraciones · Patri S. Rodeiro

Aplicación de valoración funcional (readaptación y rendimiento) y formulario previo para clientes.

- `index.html` → tu plantilla de valoración (solo para ti).
- `formulario/index.html` → formulario que rellena el cliente en casa.
- `manifest.webmanifest` e `icon-*.png` → para instalarla en el iPad como una app.

## Dónde se guardan los datos

En el propio dispositivo (iPad), dentro del navegador. GitHub solo aloja el código: **ningún dato de clientes se sube a GitHub**.

Por eso:
1. Usa siempre el mismo dispositivo y el mismo navegador (Safari en el iPad).
2. Añádela a la pantalla de inicio (Compartir → Añadir a pantalla de inicio).
3. Haz una **copia de seguridad cifrada cada semana** (botón «Copia de seguridad») y guárdala en tu ordenador o en Drive.
4. No borres «Historial y datos de sitios web» de Safari: borraría también las valoraciones.

## Actualizar

Cuando haya una versión nueva, sustituye los archivos en GitHub (Add file → Upload files). Tus datos no se tocan porque están en el iPad, no en los archivos.
